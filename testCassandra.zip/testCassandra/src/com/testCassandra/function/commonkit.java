package com.testCassandra.function;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;

import com.testCassandra.dom.fileLineBean;
import com.testCassandra.dom.parameterBean;

public class commonkit {

	
	/**
	 * 获取当前系统时间的毫秒数
	 * @return
	 */
	public Long Time(){
		Date dt= new Date();
		long start = dt.getTime();
		return start;
	}
	
	/**
	 * 获取时间差的毫秒数
	 * @param t1
	 * @param t2
	 * @return
	 */
	public Long timer(Long t1, Long t2){
		long timer = t2 - t1;
		return timer;
	}
	
	//将毫秒转换为小时，分，秒
	public String consumeTime(Long ms) {
		String result = "";
//		long days = ms / (1000 * 60 * 60 * 24);
//		long hours = (ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
//		long minutes = (ms % (1000 * 60 * 60)) / (1000 * 60);
		long seconds = (ms % (1000 * 60)) / 1000;
//		result =  " days " + hours + " hours " + minutes + " minutes "+ seconds + " seconds ";
		result = ""+seconds;
		return result;
	}
	
	/**
	 * 按行读取文件
	 * @param filePath
	 * @return
	 */
	
	@SuppressWarnings("resource")
	public ArrayList<fileLineBean> fetchLine(String filePath) {
		ArrayList<fileLineBean> result = new ArrayList<fileLineBean>();
		try {
			File file = new File(filePath);
			BufferedReader reader = null;
			String line = null;
			reader = new BufferedReader(new FileReader(filePath));
			while((line = reader.readLine())!=null) {
				fileLineBean pfb = new fileLineBean();
				pfb.setLine(line);
				result.add(pfb);
			}
		} catch (Exception efetchLine) {
			efetchLine.printStackTrace();
		}
		return result;
	}
	
	
	
	
//	//读取文件配置
//	public String fetchFile(String input) {
////		String result[9] = ;
//		String[] str = null;
//		str = input.split(":");
//		if(str[0].equals("ksname")) {
////			result[0] = str[1];
//		}
//			
////		ArrayList list = new ArrayList();
////		try {
////			File file = new File(filePath);
////			 BufferedReader reader = null;
////	         String line = null;
////	         String[] str = null;
////	         reader = new BufferedReader(new FileReader(filePath));
////	         while((line = reader.readLine())!=null){
////	        	 str = line.split(" ");
////	        	parameterBean pb = new parameterBean();
//////	        	ksname devices sensors threads loop
////	        	pb.setKsname(str[0]);
////	        	pb.setDevices(Integer.valueOf(str[1]));
////	        	pb.setSensors(Integer.valueOf(str[2]));
////	        	pb.setThreads(Integer.valueOf(str[3]));
////	        	pb.setLoop(Integer.valueOf(str[4]));
////	        	pb.setHost(str[5]);
////	        	pb.setUser(str[6]);
////	        	pb.setPass(str[7]);
////	        	list.add(pb);
////	        	 
////	         }
////		} catch (Exception eDBList) {
////			eDBList.printStackTrace();
////		}
//		return "0";
//	}
}
