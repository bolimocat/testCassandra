//查询数据案例
package com.testCassandra.function;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;

public class cassQuery {
	
	private static Cluster cluster;
	private static Session session;
	private String ksname;
	private String host;
	private String user;
	private String pass;
	public  static Long fasted = 0l;
	public  static Long slowed = 0l;
	public  static Long all = 0l;
	public  static int num = 0;
	
	commonkit ck = new commonkit();
	
	public cassQuery(String k,String h,String u,String p) {
		ksname = k;
		host = h;
		user = u;
		pass = p;

	}
	
	
	
	public void query() {
		Cluster cluster = Cluster.builder().addContactPoint(host).withCredentials(user, pass).build();
		System.out.println("查询_到此没问题");
		Session session = cluster.connect(ksname);
		String query1 = "select * from emp;";		
		ResultSet result = session.execute(query1 );
		System.out.println(result.all());
		session.close();
		cluster.close();
	}
	
	public void insert(String insertStr) {
		Cluster cluster = Cluster.builder().addContactPoint(host).withCredentials(user, pass).build();
//		System.out.println("写入_到此没问题");
//		System.out.println("cassQuery_ksname = "+ksname);
//		System.out.println("cassQuery_insertStr = "+insertStr);
		Session session = cluster.connect(ksname);
		Long start = ck.Time();
		session.execute(insertStr);
		Long end = ck.Time();
		Long consume = ck.timer(start, end);
		System.out.println("执行写入，消耗时间： "+consume+" 毫秒。");
//		System.out.println("执行写入，消耗时间： "+ck.consumeTime(consume)+" 秒。");
		num = num + 1;
		all = all + consume;
		if(consume < fasted ) {
			fasted = consume;
		}
		if(consume >= fasted ) {
			fasted = fasted;
		}
		if(consume > slowed) {
			slowed = consume;
		}
		if(consume <= slowed) {
			slowed = slowed;
		}
		session.close();
		cluster.close();
		System.out.println("fasted : "+fasted+" slowed ： "+slowed+" 完成次数： "+num+"  总耗时： "+all);
		System.out.println("完成操作次数： "+num);
		System.out.println("操作总耗时： "+all);
	}
	
	public void showResult() {
		System.out.println("本次执行，最少用时： "+fasted+"ms ，最高用时： "+slowed+"ms");
		System.out.println("本次执行，总时间： "+all+" ，次数： "+num);
		System.out.println("平均写入耗时： "+all / num);
	}

}
