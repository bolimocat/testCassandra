package com.testCassandra.function;

import java.util.ArrayList;

import com.datastax.*;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.testCassandra.dom.fileLineBean;
import com.testCassandra.dom.parameterBean;

public class main {

//	 private static Cluster cluster;
//	 private static Session session;
//	 private ResultSet result;

//	pb.getKsname());
//	pb.getDevices());
//	pb.getSensors());
//	pb.getThreads());
//	pb.getLoop());
//	pb.getHost();
//	pb.getUser();
//	pb.getPass();

	public static void main(String[] args) throws Exception {
		
		
		String[] str = null;
		String host = "";
		String user = "";
		String pass = "";
		String ksname = "";
		int threads = 0;
		int devices = 0;
		int sensors = 0;
		int times = 0;
		
		
		System.out.println(" --- ");
		commonkit ck = new commonkit();
		ArrayList paraLine = ck.fetchLine("/home/lming/myDevelopment/cassandraPara");
		fileLineBean flb0 = (fileLineBean)paraLine.get(0);
		str = flb0.getLine().split(":");
		host = str[1];
		
		fileLineBean flb1 = (fileLineBean)paraLine.get(1);
		str = flb1.getLine().split(":");
		user = str[1];
		
		fileLineBean flb2 = (fileLineBean)paraLine.get(2);
		str = flb2.getLine().split(":");
		pass = str[1];
		
		fileLineBean flb3 = (fileLineBean)paraLine.get(3);
		str = flb3.getLine().split(":");
		ksname = str[1];
		
		fileLineBean flb4 = (fileLineBean)paraLine.get(4);
		str = flb4.getLine().split(":");
		threads = Integer.valueOf(str[1]);

		fileLineBean flb5 = (fileLineBean)paraLine.get(5);
		str = flb5.getLine().split(":");
		devices = Integer.valueOf(str[1]);
		
		fileLineBean flb6 = (fileLineBean)paraLine.get(6);
		str = flb6.getLine().split(":");
		sensors = Integer.valueOf(str[1]);
		
		fileLineBean flb7 = (fileLineBean)paraLine.get(7);
		str = flb7.getLine().split(":");
		times = Integer.valueOf(str[1]);
	
		System.out.println("flb0.getLine() "+flb0.getLine());
		System.out.println("host = "+host);
		
		
//		int threadnum = 16; // 并发线程数
//		int devices = 20; // 设备数，表数。
//		int sensors = 50; // 传感器数，字段数。50
//		int times = 100; // 循环写入次数。

		
		
		cassCreate cc = new cassCreate(host, user, pass, ksname);
		
		cc.createks();
//		cc.createtb();

		// 500个传感器
		generateStr gs = new generateStr(sensors);

//		runQuery rq = new runQuery("test_ks");

//		设备数对应表数
		for (int i = 0; i < devices; i++) {
			System.out.println("create table tb" + i + " (" + gs.createTbStr());
			cc.createtb("create table tb" + i + " (" + gs.createTbStr());
		}
		System.out.println("完成表创建");

		

		// 8线程并发，循环10次写
		for(int loop=0;loop<times;loop++) {
		for (int a = 0; a < threads; a++) {

				for (int tbnum = 0; tbnum < devices; tbnum++) {
					Thread ta = new Thread(new runInsert(gs.createInsStr("tb",tbnum),ksname,devices));
					ta.start();
					Thread.sleep(2000);
					
				}
			
		}
		
			
		}
		
		System.out.println("  -- 完成写入 --  ");
		cassQuery cq = new cassQuery(ksname,host, user, pass);
		cq.showResult();
//		System.out.println("本次执行，最少用时： "+cassQuery.fasted+"ms ，最高用时： "+cassQuery.slowed+"ms");
//		System.out.println("本次执行，总时间： "+cassQuery.all+" ，次数： "+cassQuery.num);
//		System.out.println("平均写入耗时： "+cassQuery.all / cassQuery.num);
		
		// 执行并发查询
//		for(int a=0;a<2;a++) {//线程数
//			for(int i=0;i<100;i++) {//每个线程完成的次数
//			
//				Thread ta = new Thread(new runQuery());
//				ta.start();
//			
//				
//			}
//		}
		
		
	}

}
