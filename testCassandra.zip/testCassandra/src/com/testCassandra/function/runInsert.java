package com.testCassandra.function;

public class runInsert implements Runnable{

	private String ksname;
	private String str;
	private int tbnum;
	
	public runInsert(String insertStr,String k,int n) {
		str = insertStr;
		ksname = k;
//		System.out.println("runInsert的构造函数的ksname = "+ksname);//正确
		tbnum = n;
		
	}
	cassQuery cq = new cassQuery("test_ks","192.168.130.15", "cassandra", "cassandra");
	
	
	
	@Override
	public void run() {
//		执行线程写入
		// TODO Auto-generated method stub
//		System.out.println("runInsert ksname : "+ksname);
//		System.out.println("runInsert str： "+str);
//		System.out.println("runInsert tbnum = "+tbnum);
		for(int num=0;num<tbnum;num++) {
//			System.out.println("线程内容插入语句："+str);
			cq.insert(str);
//			System.out.println("完成一次插入线程");
		}
		
		
	}

}
