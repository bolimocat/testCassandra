package com.testCassandra.function;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;


public class cassCreate {
	
	private static Cluster cluster;
	private static Session session;
	private String host;
	private String user;
	private String pass;
	private String ksname;
	
	public cassCreate(String h,String u,String p,String k) {
		host = h;
		user = u;
		pass = p;
		ksname = k;
	}
	
	
	public void createks() {
//		Cluster cluster = Cluster.builder().addContactPoint("192.168.130.15").withCredentials("cassandra", "cassandra").build();
//		System.out.println("创建keyspace_到此没问题");
		String query = "CREATE KEYSPACE "+ksname+" WITH replication = {'class':'SimpleStrategy', 'replication_factor':1};";
		Cluster cluster = Cluster.builder().addContactPoint(host).withCredentials(user, pass).build();
		Session session = cluster.connect();
		session.execute(query);
		System.out.println("Keyspace created : "+ksname); 
		session.close();
		cluster.close();
	}
	
	public void createtb(String createtbStr) {
		Cluster cluster = Cluster.builder().addContactPoint(host).withCredentials(user, pass).build();
		Session session = cluster.connect(ksname);
		session.execute(createtbStr);
		System.out.println("Table created "+createtbStr);
		session.close();
		cluster.close();
		
	}
	
	public void droptb(String dropTbStr) {
		Cluster cluster = Cluster.builder().addContactPoint(host).withCredentials(user, pass).build();
		Session session = cluster.connect(ksname);
		session.execute(dropTbStr);
		System.out.println("Table droped "+dropTbStr);
		session.close();
		cluster.close();
	}

}

//cassandra