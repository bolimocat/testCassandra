//测量
package com.testCassandra.function;

public class measureResult {

	
	//
	
	//比较结果取小值
	public float minTime() {
		float minTime = 0;
		return minTime;
	}
}
