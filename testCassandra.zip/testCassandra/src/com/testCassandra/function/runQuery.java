package com.testCassandra.function;

public class runQuery implements Runnable{

	private String ksname;
	
	public runQuery(String k) {
		ksname = k;
	}
	
	cassQuery cq = new cassQuery(ksname,"192.168.130.15", "cassandra", "cassandra");
	
	@Override
	public void run() {
//		执行线程查询
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
		cq.query();
	}

	
	

}
