//生成建表语句
package com.testCassandra.function;

import java.util.ArrayList;

public class generateStr {

//	private int devices;
	private int sensors;
	
	public generateStr(int s) {
//		devices = d;
		sensors = s;
	}
	
	/**
	 * 生成建表需要的语句
	 * @param sensor
	 * @return
	 */
	public String createTbStr() {
		String createTbStr = "";
		for(int i=0;i<sensors;i++) {
			createTbStr = "s_"+i+" int," + createTbStr + "";
		}
		createTbStr = createTbStr + " ctime timestamp primary key)";
		return createTbStr;
	}
	
	/**
	 * 生成写入语句
	 * @param tbname
	 * @param sensor
	 * @return
	 */
	public String createInsStr(String tbname,int devices) {
		commonkit ck = new commonkit();
		int max=100,min=1;
		
		String createInsStr = "";
		String str0 = "";
		String str1 = "";
		String str2 = "";
		for(int i=0;i<sensors;i++) {
			str0 = devices + "" + str0;
			str1 = "s_"+i+","+str1;
			str2 = (int) (Math.random()*(max-min)+min) +","+ str2;
		}
		createInsStr = "insert into "+tbname+""+devices+" ( "+str1+" ctime ) values ("+str2+""+ck.Time()+")";
		return createInsStr;
	}
}
