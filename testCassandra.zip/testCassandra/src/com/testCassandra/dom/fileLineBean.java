package com.testCassandra.dom;

public class fileLineBean {
	
	private String line;

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

}
