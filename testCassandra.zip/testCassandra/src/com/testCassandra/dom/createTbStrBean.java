package com.testCassandra.dom;

public class createTbStrBean {
	
	private String createTbStr;

	public String getCreateTbStr() {
		return createTbStr;
	}

	public void setCreateTbStr(String createTbStr) {
		this.createTbStr = createTbStr;
	}

}
